from fastapi import FastAPI, UploadFile, File, HTTPException
import librosa, numpy as np, tempfile, os

app = FastAPI(title="Sesinden Şarkı - Melody Analysis API")

@app.get("/")
def root():
    return {"status": "ok", "message": "Sesinden Şarkı analiz sunucusu çalışıyor."}

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    suffix = os.path.splitext(file.filename or "recording.m4a")[1] or ".m4a"
    try:
        payload = await file.read()
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp.write(payload)
            path = tmp.name
        y, sr = librosa.load(path, sr=22050, mono=True)
        os.unlink(path)
        if len(y) < sr // 2:
            raise HTTPException(400, "Kayıt çok kısa.")
        f0, voiced_flag, voiced_probs = librosa.pyin(
            y, fmin=librosa.note_to_hz("C2"), fmax=librosa.note_to_hz("C7"),
            sr=sr, frame_length=2048, hop_length=256
        )
        times = librosa.times_like(f0, sr=sr, hop_length=256)
        notes, previous, last_time = [], None, -1.0
        # Group adjacent frames into note events; ignore very short detections.
        for t, hz, prob in zip(times, f0, voiced_probs):
            if hz is None or not np.isfinite(hz) or prob < 0.55:
                previous = None
                continue
            midi = int(round(librosa.hz_to_midi(float(hz))))
            name = librosa.midi_to_note(midi)
            if name != previous and (not notes or t - last_time > 0.10):
                notes.append({"note": name, "midi": midi, "time": round(float(t), 2)})
                last_time = float(t)
            previous = name
        # Compact repeated notes and cap response size.
        compact = []
        for n in notes:
            if not compact or compact[-1]["note"] != n["note"]:
                compact.append(n)
        return {"notes": compact[:256], "duration_seconds": round(len(y)/sr, 2)}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(422, f"Ses analiz edilemedi: {str(exc)}")
